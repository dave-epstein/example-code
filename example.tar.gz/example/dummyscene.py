from dataclasses import dataclass
from typing import Callable, Union, TypeVar, Tuple

import torch
from torch import nn, Tensor

__all__ = ["DummySceneModel"]

def freeze(model: nn.Module):
    for param in model.parameters():
        param.requires_grad = False
T = TypeVar('T')
NTuple = Tuple[T, ...]


@dataclass(eq=False)
class DummySceneModel(nn.Module):
    model: Union[nn.Module, Callable[[], nn.Module]]
    generator: Union[nn.Module, Callable[[], nn.Module]]
    resolution: int
    dim: int
    n_imgs: int = 1
    n_latent_enc_layers: int = 4
    n_latent_dec_layers: int = 4

    def __post_init__(self):
        super().__init__()
        self.generator = self.generator()
        self.model = self.model()
        freeze(self.generator)
        model_dim = self.dim
        _layers = []
        for i in range(self.n_latent_enc_layers):
            _layers.extend([nn.Linear(model_dim if i else self.dim, model_dim), nn.SiLU()])
        _layers = _layers[:-1]  # Remove last activation function
        self.latent_encoder = nn.Sequential(*_layers)
        _layers = []
        for i in range(self.n_latent_dec_layers):
            _layers.extend([nn.Linear(self.generator.dim if i else model_dim, self.generator.dim), nn.SiLU()])
        _layers = _layers[:-1]  # Remove last activation function
        self.latent_decoder = nn.Sequential(*_layers)

    def forward(self, *args, **kwargs):
        return self.predict_masks_and_latents(*args, **kwargs)

    def predict_masks_and_latents(self, z: Tensor) -> NTuple[Tensor]:
        z = self.latent_encoder(z)
        imgs_and_masks = torch.zeros((len(z), 4, self.resolution, self.resolution)).type_as(z).requires_grad_()
        mask, bottleneck = self.model(imgs_and_masks, return_bottleneck=True)
        masks = [mask.sigmoid()]
        latents = [self.latent_decoder(bottleneck)]
        imgs = [self.generator.latent_to_img(latents[0])]
        return torch.stack(masks, 1), torch.stack(imgs, 1)
