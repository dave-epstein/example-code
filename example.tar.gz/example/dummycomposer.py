from __future__ import annotations

__all__ = ["DummySceneComposer"]

import os
from dataclasses import dataclass
from typing import Optional, Union, List, Any, TypeVar

import torch
import torch.nn.functional as F
import torch.optim as optim
from fairscale.nn import wrap, checkpoint_wrapper
from pytorch_lightning import LightningModule
from torch import nn, Tensor
from torchvision.models import resnet50
from torchvision.models.resnet import Bottleneck

from dummyscene import DummySceneModel
from dummynetworks import DummyIm2Im, DummyGenerator

T = TypeVar('T')
FromConfig = Union[T, dict[str, Any]]


@dataclass(eq=False)
class DummySceneComposer(LightningModule):
    # Module parameters
    dim: int = 1024
    resolution: int = 256
    # Optimization
    lr: float = 1e-3
    eps: float = 1e-5
    checkpoint: bool = False

    def __post_init__(self):
        super().__init__()
        self.save_hyperparameters()
        self.checkpoint_modules = [Bottleneck] if self.checkpoint else []  # TODO

    def configure_sharded_model(self):
        # wrap and auto_wrap are no-ops if 'fsdp' not in `trainer.plugins`
        self.discriminator = self._checkpoint_and_shard(resnet50(num_classes=1))
        self.generator = self._checkpoint_and_shard(
            DummySceneModel(resolution=self.resolution, dim=self.dim, model=lambda: DummyIm2Im(4, 1),
                            generator=lambda: DummyGenerator(self.resolution, self.dim)))

    def configure_optimizers(self) -> Union[optim, List[optim]]:
        _requires_grad = lambda p: p.requires_grad
        G_optim = torch.optim.AdamW(filter(_requires_grad, self.generator.parameters()), lr=self.lr, eps=self.eps)
        D_optim = torch.optim.Adam(filter(_requires_grad, self.discriminator.parameters()), lr=self.lr, eps=self.eps)
        return G_optim, D_optim

    # Training and evaluation
    def shared_step(self, batch: tuple[Tensor, dict], batch_idx: int,
                    optimizer_idx: Optional[int] = None, mode: str = 'train') -> Optional[Union[Tensor, dict]]:
        train = mode == 'train'
        train_G = train and optimizer_idx == 0
        train_D = train and optimizer_idx == 1
        batch_real = batch[0]
        z = torch.randn(len(batch_real), self.dim).type_as(batch_real)

        # Generate images and collage them
        masks, gen_img_seqs = self.generator(z.requires_grad_())  # z requires grad for gradient checkpointing
        gen_imgs = (gen_img_seqs * masks)[:, 0]

        # Compute various losses
        losses = dict()

        # Run fake images through D - individual fake images as well as both correct and bad collages
        logits_fake = self.discriminator(gen_imgs)
        if train_G or not train:
            losses['G_log'] = F.softplus(-logits_fake).mean()
        if train_D or not train:
            logits_real = self.discriminator(batch_real)
            # Log
            losses['D_log_real'] = F.softplus(-logits_real).mean()
            losses['D_log_fake'] = F.softplus(logits_fake).mean()

        # Compute final loss and log
        losses['total_loss'] = sum(map(lambda k: losses[k], losses))
        if self.alert_nan_loss(losses['total_loss'], batch_idx):
            return
        # Further logging and terminate
        if mode == "train":
            return losses['total_loss']

    # Control flow
    def training_step(self, batch: tuple[Tensor, dict], batch_idx: int, optimizer_idx: Optional[int] = None) -> Tensor:
        return self.shared_step(batch, batch_idx, optimizer_idx, 'train')

    def validation_step(self, batch: tuple[Tensor, dict], batch_idx: int):
        return self.shared_step(batch, batch_idx, mode='validate')

    def test_step(self, batch: tuple[Tensor, dict], batch_idx: int):
        return self.shared_step(batch, batch_idx, mode='test')

    def alert_nan_loss(self, loss: Tensor, batch_idx: int):
        if loss != loss:
            print(
                f'NaN loss in epoch {self.current_epoch}, batch index {batch_idx}, global step {self.global_step}, '
                f'local rank {os.environ.get("LOCAL_RANK", -1)}. Skipping.')
        return loss != loss

    def _checkpoint_and_shard(self, m):
        return wrap(self.wrap_checkpoints(root=m, modules=self.checkpoint_modules, offload_to_cpu=True))

    def wrap_checkpoints(self, modules: list[type], blacklist: Optional[list[str]] = None,
                         root: Optional[nn.Module] = None, **checkpoint_kwargs):
        root = root or self
        count = 0
        if blacklist is None:
            blacklist = []
        for n, m in root.named_modules():
            if any([n.startswith(s) for s in blacklist]) or getattr(m, '_checkpointed', False):
                continue
            if any([isinstance(m, m_) for m_ in modules]):
                root.get_submodule(n).apply(lambda mm: setattr(mm, '_checkpointed', True))
                parent_n, n = n.rsplit('.', 1)
                setattr(root.get_submodule(parent_n), n, checkpoint_wrapper(m, **checkpoint_kwargs))
                count += 1
        print(f'Checkpointed {count} modules of type {modules}')
        return root
