from dataclasses import dataclass
from typing import Any
import os
import hydra
import omegaconf
import pytorch_lightning as pl
import torch
from omegaconf import OmegaConf
from pytorch_lightning import seed_everything, LightningDataModule
from torch.utils.data import DataLoader, Dataset

from dummycomposer import DummySceneComposer


class DummyDataset(Dataset):
    def __init__(self, shape, num_samples: int = 10000):
        super().__init__()
        self.shape = shape
        self.num_samples = num_samples

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx: int):
        return [torch.rand(*self.shape)]
def is_rank_zero():
    rank = int(os.environ.get("LOCAL_RANK", 0))
    return rank == 0

@dataclass
class RandomDataModule(LightningDataModule):
    dataloader: dict[str, Any]
    res: int
    train_size: int = 10000
    validate_size: int = 10000
    test_size: int = 10000

    def __post_init__(self):
        super().__init__()

    def train_dataloader(self) -> DataLoader:
        return self._get_dataloader(self.train_size)

    def val_dataloader(self) -> DataLoader:
        return self._get_dataloader(self.validate_size)

    def test_dataloader(self) -> DataLoader:
        return self._get_dataloader(self.test_size)

    def _get_dataloader(self, size) -> DataLoader:
        return DataLoader(DummyDataset((3, self.res, self.res), size), **self.dataloader)


@hydra.main(config_path="configs", config_name="fit_debug")
def run(config: omegaconf.DictConfig):
    if is_rank_zero():
        print('CONFIG')
        print(OmegaConf.to_yaml(config, resolve=True))

    seed_everything(0, workers=True)

    datamodule = RandomDataModule(config.dataset.dataloader, config.dataset.resolution)

    model = DummySceneComposer(**config.model)

    trainer = pl.Trainer(**config.trainer)

    if config.mode == 'fit':
        trainer.fit(model, datamodule=datamodule)
    elif config.mode == 'validate':
        trainer.validate(model, datamodule=datamodule)
    elif config.mode == 'test':
        trainer.test(model, datamodule=datamodule)


if __name__ == "__main__":
    run()
